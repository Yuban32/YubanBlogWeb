import{_ as l}from"./index.67ca4633.js";import{I as i}from"./_@vue_shared@3.2.22@@vue.6292bdea.js";import{l as t,m as r,q as a,F as n,A as u,x as h,y as d}from"./_@vue_runtime-core@3.2.22@@vue.1e96a215.js";const m={id:"article-title-wrap"},A={props:{title:String},setup(e){return(s,o)=>(t(),r("div",m,[a("h1",null,i(e.title),1)]))}},v={props:{tagText:Array}},f=e=>(h("data-v-4f4bd2e6"),e=e(),d(),e),g={id:"tag-wrap"},b=f(()=>a("svg",{t:"1637673169176",class:"icon",viewBox:"0 0 1024 1024",version:"1.1",xmlns:"http://www.w3.org/2000/svg","p-id":"5506",width:"200",height:"200"},[a("path",{d:"M469.333533 968.08a52.986667 52.986667 0 0 1-37.713333-15.62l-416-416A52.986667 52.986667 0 0 1 0.0002 498.746667V138.666667a53.393333 53.393333 0 0 1 53.333333-53.333334h360.08a52.986667 52.986667 0 0 1 37.713334 15.62l416 416a53.4 53.4 0 0 1 0 75.426667l-360.08 360.08a52.986667 52.986667 0 0 1-37.713334 15.62zM53.333533 128a10.666667 10.666667 0 0 0-10.666666 10.666667v360.08a10.573333 10.573333 0 0 0 3.126666 7.54l416 416a10.666667 10.666667 0 0 0 15.08 0l360.08-360.08a10.666667 10.666667 0 0 0 0-15.08l-416-416a10.573333 10.573333 0 0 0-7.54-3.126667z m224 341.333333c-58.813333 0-106.666667-47.853333-106.666666-106.666666s47.853333-106.666667 106.666666-106.666667 106.666667 47.853333 106.666667 106.666667-47.853333 106.666667-106.666667 106.666666z m0-170.666666a64 64 0 1 0 64 64 64.073333 64.073333 0 0 0-64-64z m335.086667 676.42l382.706667-382.706667a53.4 53.4 0 0 0 0-75.426667L569.753533 91.58a21.333333 21.333333 0 0 0-30.173333 30.173333l425.373333 425.373334a10.666667 10.666667 0 0 1 0 15.08l-382.706666 382.706666a21.333333 21.333333 0 0 0 30.173333 30.173334z",fill:"#3379f6","p-id":"5507"})],-1)),y={class:"tag-text-wrap"};function S(e,s,o,j,x,w){return t(),r("div",g,[b,a("ul",y,[(t(!0),r(n,null,u(o.tagText,(p,c)=>(t(),r("li",{class:"tag-text hover-up",key:c},i(p),1))),128))])])}var _=l(v,[["render",S],["__scopeId","data-v-4f4bd2e6"]]),J={1:{articleId:1,articleText:[{html:"",css:`
            <p>\u9996\u5148\u6211\u4EEC\u5148\u6765\u4E86\u89E3\u4E00\u4E0BCSS\u65B0\u7684\u7279\u6027</p>
            <p>var()\u51FD\u6570\u548C:root\u4F2A\u7C7B\u9009\u62E9\u5668\u8FD8\u6709CSS\u53D8\u91CF</p>
            <p>var() \u7528\u4E8E\u63D2\u5165\u81EA\u5B9A\u4E49\u7684\u5C5E\u6027\u503C\uFF0C\u652F\u6301\u7248\u672C\uFF1ACSS3</p>
            <p>\u4E0B\u9762\u662F\u4EE3\u7801\u793A\u4F8B</p>`,js:"\u56E0\u4E3A\u5176\u4ED6\u7684\u65B9\u6CD5CSS\u4E0D\u4F1A\u91CD\u8F7D\uFF0C\u6240\u4EE5\u5C31\u76F4\u63A5\u901A\u8FC7document.documentElement\u6765\u76F4\u63A5\u4FEE\u6539CSS\u6837\u5F0F\u4E86\u3002",end:"\u53EA\u662F\u63D0\u4F9B\u4E86\u4E00\u4E2A\u6838\u5FC3\u7684\u90E8\u5206\uFF0CCSS\u7B49\u5176\u4ED6\u6837\u5F0F\u7F8E\u5316\u8FD8\u5F97\u5927\u4F19\u513F\u505A\u55F7~"}],articleTitle:"Vue3+vite\u7684\u4E3B\u9898\u5207\u6362\u529F\u80FD",imgSrc:["https://yubanblog-1254028239.cos.ap-guangzhou.myqcloud.com/article/vue_logo.svg"],tagTextArr:["\u524D\u7AEF","Vue","JS"],articleDate:"2021-11-23",checkNum:"114514",describe:"\u8FD9\u4E2A\u662F\u4E00\u4E2A\u57FA\u4E8EVue3\u7684\u5168\u5C40\u4E3B\u9898\u5207\u6362\u529F\u80FD\uFF0C\u5229\u7528CSS\u7684\u53D8\u91CF\u529F\u80FD\u6765\u505A\u4E3A\u5168\u5C40\u53D8\u91CF,\u5229\u7528CSS3\u7684\u5168\u5C40\u53D8\u91CF\u6765\u505A\u7684",codeLine:[{html:"",css:`
 /* CSS */
    :root{
        --nav-text-color:#3379f6;
        --nav-bg-color:#fff;
    }`,js:`
//JS
    data(){
        return{
            white:{
                navTextColor:'#3379f6',
                navBgColor:'#fff'
            },
            state:'white'
        }
    },
    methods:{
        const root = document.documentElement;
        if(this.state=='white'){
            //dark
            var dark = {
                navTextColor:'#f5f6f7',
                navBgColor:'#242526'
            }
            this.state = 'dark';
            root.style.setProperty('--nav-text-color',dark.navTextColor);
            root.style.setProperty('--nav-bg-color',dark.navBgColor);
        }else if(this.state == 'dark'){
            this.state = 'white';
            root.style.setProperty('--nav-text-color',this.white.navTextColor);
            root.style.setProperty('--nav-bg-color',this.white.navBgColor);
        }
    },
    //\u628A\u6570\u636E\u4FDD\u5B58\u5230\u672C\u5730localStorage
    created(){
        //\u5982\u679C\u672C\u5730\u6CA1\u6709\u5B58\u50A8\u6837\u5F0F\u7684\u8BDD \u5C31\u8BBE\u5B9A\u521D\u59CB\u503C
        const root = document.documentElement;
        if(localStorage.getItem('theme')!=null){
            let themes = JSON.parse(localStorage.getItem('theme'));
            root.style.setProperty('--nav-text-color',this.white.navTextColor);
            root.style.setProperty('--nav-bg-color',this.white.navBgColor);
        }else{
            localStorage.setItem('theme',JSON.stringify(this.white))
        }
    }
            `}],subtitle:{html:"",css:"CSS\u90E8\u5206",js:"JS\u90E8\u5206",end:"END"}},2:{articleId:2,articleText:[{html:`<p>\u5728\u5199\u672C\u9879\u76EE\u7684\u65F6\u5019\u9047\u5230\u4E00\u4E2A\u95EE\u9898\uFF0C\u5C31\u662F\u8DEF\u7531\u8DF3\u8F6C\u5230\u5F53\u524D\u7EC4\u4EF6\u540E\u6570\u636E\u4E0D\u53D1\u751F\u66F4\u65B0\uFF0C
            \u5B9E\u6D4B\u662F\u8DEF\u7531\u6709\u7F13\u5B58\u529F\u80FD\uFF0C\u89E3\u51B3\u529E\u6CD5\u5C31\u662F\u5728\u8DEF\u7531\u51FA\u53E3<router-view />\u52A0\u4E0A :key="$route.fullPath"</p>
            <p>\u901A\u8FC7\u7ED1\u5B9A\u4E00\u4E2AfullPath\uFF0C\u53EF\u4EE5\u8BC6\u522B\u5F53\u524D\u9875\u9762\u8DEF\u7531\u7684\u5B8C\u6574\u5730\u5740\uFF0C\u5F53\u5730\u5740\u53D1\u751F\u6539\u53D8(\u5305\u62EC\u53C2\u6570\u6539\u53D8)\u5219\u91CD\u65B0\u6E32\u67D3\u9875\u9762(\u4F8B\u5982\u52A8\u6001\u8DEF\u7531\u53C2\u6570\u7684\u53D8\u5316)</p>`,css:"",js:"",end:""}],articleTitle:"Vue\u8DEF\u7531\u4E0D\u5237\u65B0\u95EE\u9898",imgSrc:["https://yubanblog-1254028239.cos.ap-guangzhou.myqcloud.com/article/vue_logo.svg"],tagTextArr:["\u524D\u7AEF","Vue","JS"],articleDate:"2021-11-23",checkNum:"114514",describe:`\u5728\u5199\u672C\u9879\u76EE\u7684\u65F6\u5019\u9047\u5230\u4E00\u4E2A\u95EE\u9898\uFF0C\u5C31\u662F\u8DEF\u7531\u8DF3\u8F6C\u5230\u5F53\u524D\u7EC4\u4EF6\u540E\u6570\u636E\u4E0D\u53D1\u751F\u66F4\u65B0\uFF0C
        \u5B9E\u6D4B\u662F\u8DEF\u7531\u6709\u7F13\u5B58\u529F\u80FD\uFF0C\u89E3\u51B3\u529E\u6CD5\u5C31\u662F\u5728\u8DEF\u7531\u51FA\u53E3<router-view />\u52A0\u4E0A :key="$route.fullPath"`,codeLine:[{html:`
&lt;!-- HTML --&gt;
&lt;router-view :key="$route.fullPath"/&gt;`,css:"",js:""}],subtitle:{html:"HTML\u90E8\u5206",css:"",js:"",end:"END"}},3:{articleId:3,articleText:[{html:"",css:"",js:`<p>\u5728\u4EE5\u524D\u539F\u751F\u7684\u7F51\u7EDC\u8BF7\u6C42\u662F\u7528XMLHttpRequest\u6765\u5B9E\u73B0\u7684\uFF0C\u4F46ES6\u65B0\u589E\u4E86Fetch\u8FD9\u4E2A\u65B9\u6CD5\uFF0CFetch\u57FA\u4E8EPromise\u7684\u4E00\u4E2A\u65B0\u4E00\u4EE3\u7684\u7F51\u7EDC\u8BF7\u6C42API</p>
            <p>Fetch\u4E0D\u4F1A\u53D1\u9001\u8DE8\u57DFCookie</p>
            <p>fetch(url) Fetch\u7B2C\u4E00\u4E2A\u53C2\u6570\u63A5\u6536\u4E00\u4E2Aurl\u8BF7\u6C42\u5730\u5740\uFF0C\u9ED8\u8BA4\u8BF7\u6C42\u65B9\u5F0F\u662FGET\u3002</p>
            <p>\u7B2C\u4E00\u6B21\u8FD4\u56DE\u7684\u662F\u4E00\u4E2APromise\u5BF9\u8C61\uFF0C\u5E76\u4E0D\u662F\u6211\u4EEC\u60F3\u8981\u7684\u4E1C\u897F\uFF0C\u6240\u4EE5\u6211\u4EEC\u9700\u8981\u628A\u8FD4\u56DE\u7684\u6570\u636E\u901A\u8FC7.json()\u65B9\u5F0F\u8F6C\u6362\u6210\u6211\u4EEC\u60F3\u8981\u7684\u4E1C\u897F</p>
            <p>\u4E0B\u9762\u4ECB\u7ECDGET\u548CPOST\u7684\u4F7F\u7528\u65B9\u6CD5</p>
            `,end:`
            <a target="_blank" href="https://www.ruanyifeng.com/blog/2020/12/fetch-tutorial.html">\u672C\u6587\u53C2\u8003\u962E\u4E00\u5CF0\u7684Fetch API \u6559\u7A0B</a>
            `}],articleTitle:"Fetch\u4F7F\u7528\u65B9\u6CD5",imgSrc:["https://yubanblog-1254028239.cos.ap-guangzhou.myqcloud.com/article/ES6.jpg"],tagTextArr:["\u524D\u7AEF","ES6","JS"],articleDate:"2021-11-23",checkNum:"114514",describe:`Fetch API \u63D0\u4F9B\u4E86\u4E00\u4E2A JavaScript \u63A5\u53E3\uFF0C\u7528\u4E8E\u8BBF\u95EE\u548C\u64CD\u7EB5 HTTP \u7BA1\u9053\u7684\u4E00\u4E9B\u5177\u4F53\u90E8\u5206\uFF0C
        \u4F8B\u5982\u8BF7\u6C42\u548C\u54CD\u5E94\u3002\u5B83\u8FD8\u63D0\u4F9B\u4E86\u4E00\u4E2A\u5168\u5C40 fetch() \u65B9\u6CD5\uFF0C\u8BE5\u65B9\u6CD5\u63D0\u4F9B\u4E86\u4E00\u79CD\u7B80\u5355\uFF0C\u5408\u7406\u7684\u65B9\u5F0F\u6765\u8DE8\u7F51\u7EDC\u5F02\u6B65\u83B7\u53D6\u8D44\u6E90\u3002`,codeLine:[{html:"",css:"",js:`
//JS
//\u9ED8\u8BA4GET\u8BF7\u6C42
fetch('https://baidu.com/')
.then(res=>res.json())
.then(res=>{
    console.log(res);
}).catch(err){
    throw err;
}
//POST\u8BF7\u6C42
fetch('http://test.com/api/submit',{
    method:'POST'
}).then(res=>res.json()).then(res=>{
    console.log(res);
}).catch(err){
    throw err;
}
//\u5B8C\u6574\u7684Fetch\u914D\u7F6E
fetch(url,{
    method:'POST', //or GET
    headers:{
        "Content-Type": "text/plain;charset=UTF-8"
      },
      body: undefined,
      referrer: "about:client",
      referrerPolicy: "no-referrer-when-downgrade",
      mode: "cors", 
      credentials: "same-origin",
      cache: "default",
      redirect: "follow",
      integrity: "",
      keepalive: false,
      signal: undefined
})
            `}],subtitle:{html:"",css:"",js:"JS\u90E8\u5206",end:"END"}},4:{articleId:4,articleText:[{html:"",css:"",js:`<p>1\u3001\u5229\u7528ES6\u7684 Set\u53BB\u91CD</p>
            <p>2\u3001\u5229\u7528for\u5FAA\u73AF\u5D4C\u5957\uFF0C\u7136\u540E\u7528splice\u53BB\u91CD</p>
            <p>3\u3001\u5229\u7528indexOf\u53BB\u91CD</p>
            <p>4\u3001\u5229\u7528include\u53BB\u91CD</p>
            <p>5\u3001\u5229\u7528hasOwnProperty\u53BB\u91CD</p>
            `,end:`
            <a target="_blank" href="https://segmentfault.com/a/1190000016418021?utm_source=tag-newest">\u672C\u6587\u53C2\u8003JavaScript\u6570\u7EC4\u53BB\u91CD\uFF0812\u79CD\u65B9\u6CD5\uFF0C\u53F2\u4E0A\u6700\u5168\uFF09</a>
            `}],articleTitle:"\u5E38\u7528\u7684\u51E0\u4E2A\u6570\u7EC4\u53BB\u91CD",imgSrc:["https://yubanblog-1254028239.cos.ap-guangzhou.myqcloud.com/article/ES6.jpg"],tagTextArr:["\u524D\u7AEF","ES6","JS"],articleDate:"2021-11-23",checkNum:"114514",describe:"\u6570\u7EC4\u53BB\u91CD\uFF0C\u5728\u9762\u8BD5\u5FC5\u95EE\u7684\u95EE\u9898\u4E4B\u4E00...\u4E00\u822CHR\u4F1A\u8981\u6C42\u9762\u8BD5\u8005\u624B\u5199\u6570\u7EC4\u53BB\u91CD\u7684\u65B9\u6CD5\uFF0C\u867D\u7136\u8BF4\u5728\u5F00\u53D1\u4E2D\u6570\u7EC4\u53BB\u91CD\u51E0\u4E4E\u90FD\u662F\u4EA4\u7ED9\u540E\u7AEF\u53BB\u5904\u7406\uFF0C\u4F46\u4F5C\u4E3A\u524D\u7AEF\u7684\u6211\u4EEC\u6570\u7EC4\u53BB\u91CD\u4E5F\u662F\u8981\u638C\u63E1\u7684",codeLine:[{html:"",css:"",js:`
//JS
//\u5229\u7528ES6 Set\u53BB\u91CD
function unique(arr){
    return Array.from(new Set(arr))
}

//\u5229\u7528for\u5FAA\u73AF\u5D4C\u5957\uFF0C\u7136\u540E\u7528splice\u53BB\u91CD
function unique(arr){
    for(var i = 0; i < arr.length; i++){
        for(var j=i+1; j < arr.length; j++){
            if(arr[i]==arr[j]){
                arr.splice(j,1);
                j--;
            }
        }
    }
    return arr
}

//\u5229\u7528indexOf\u53BB\u91CD
function unique(arr) {
    if (!Array.isArray(arr)) {
        console.log('type error!')
        return
    }
    var array = [];
    for (var i = 0; i < arr.length; i++) {
        if (array .indexOf(arr[i]) === -1) {
            array .push(arr[i])
        }
    }
    return array;
}

//\u5229\u7528include\u53BB\u91CD
function unique(arr) {
    if (!Array.isArray(arr)) {
        console.log('type error!')
        return
    }
    var array =[];
    for(var i = 0; i < arr.length; i++) {
            if( !array.includes( arr[i]) ) {//includes \u68C0\u6D4B\u6570\u7EC4\u662F\u5426\u6709\u67D0\u4E2A\u503C
                    array.push(arr[i]);
              }
    }
    return array
}

//\u5229\u7528hasOwnProperty
function unique(arr) {
    var obj = {};
    return arr.filter(function(item, index, arr){
        return obj.hasOwnProperty(typeof item + item) ? false : (obj[typeof item + item] = true)
    })
}
            `}],subtitle:{html:"",css:"",js:"JS\u90E8\u5206",end:"END"}},5:{articleId:5,articleText:[{html:"",css:"",js:`
            <p>1\u3001for\u5FAA\u73AF</p>
            <p>2\u3001forEach\u5FAA\u73AF</p>
            <p>3\u3001reduce</p>
            <p>4\u3001eval</p>
            `,end:""}],articleTitle:"JavaScript\u6570\u7EC4\u6C42\u548C\u7684\u5E38\u7528\u65B9\u6CD5",imgSrc:["https://source.unsplash.com/1200x900/epic"],tagTextArr:["\u524D\u7AEF","JS"],articleDate:"2021-11-23",checkNum:"114514",describe:"JS\u6570\u7EC4\u6C42\u548C\u7684\u5E38\u7528\u65B9\u6CD5\u3002",codeLine:[{html:"",css:"",js:`
//JS
//for\u5FAA\u73AF
function sum(arr) {
    var temp = 0;
    for (var i = 0;i < arr.length;i++) {
      temp += arr[i];
    }
    return temp;
}

//forEach\u5FAA\u73AF
function sum(arr){
    var temp = 0
    arr.forEach(val=>{
        temp += val;
    })
    return temp;
}

//reduce
function sum(arr) {
    return arr.reduce((acr, cur)=>{
      return acr + cur;
    });
}

//eval
function sum(arr) {
    return eval( arr.join("+"));
}
            `}],subtitle:{html:"",css:"",js:"JS\u90E8\u5206",end:"END"}},6:{articleTitle:"JavaScript\u6392\u5E8F\u7B97\u6CD5",articleId:6,articleText:[{html:"",css:"",js:`
            <p>1\u3001\u5192\u6CE1\u6392\u5E8F</p>
            <p>2\u3001\u9009\u62E9\u6392\u5E8F</p>
            <p>3\u3001\u63D2\u5165\u6392\u5E8F</p>
            `,end:""}],imgSrc:["https://api.yimian.xyz/img?type=wallpaper"],tagTextArr:["\u524D\u7AEF","JS"],articleDate:"2021-11-23",checkNum:"114514",describe:"JavaScript\u5E38\u7528\u7684\u6392\u5E8F\u7B97\u6CD5\uFF0C\u672C\u6587\u4F1A\u4ECB\u7ECD\u4E00\u4E9B\u8BA1\u7B97\u673A\u79D1\u5B66\u4E2D\u6700\u8457\u540D\u7684\u6392\u5E8F\u7B97\u6CD5\u3002",codeLine:[{html:"",css:"",js:`
//JS
//\u5192\u6CE1\u6392\u5E8F
function bubbleSort(array){
    for (let i = array.length;i > 0; i--){
        for (let j=0; j < i;j++){
            if (array[j] > array[j+1]){
                var temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            }
        }
    }
    return array;
}
//\u9009\u62E9\u6392\u5E8F
function selectionSort(array){
    for(var i = 0;i < arr.length - 1; i++){
     var maxone = i;
     for(var j = i; j < arr.length;j++){
      if(arr[j] < arr[maxone]){
       maxone = j;
       var temp = arr[i];
       arr[i] = arr[maxone];
       arr[maxone] = temp;
      }
     }
    }
    return arr;
   }
//\u63D2\u5165\u6392\u5E8F
function insertionSort(array){
    let length = arr.length;
  for(let i = 1; i < length; i++) {
    let temp = arr[i];
    let j = i;
    for(; j > 0; j--) {
      if(temp >= arr[j-1]) {
        break;
      }
      arr[j] = arr[j-1];
    }
    arr[j] = temp;
  }
  return arr;
}
            `}],subtitle:{html:"",css:"",js:"JS\u90E8\u5206",end:"END"}},7:{articleId:7,articleTitle:"Vite\u5F15\u5165Vue-touter4",describe:"Vite\u5F15\u5165Vue-touter4",articleText:[{html:"",css:"",js:`
            <p>1\u3001\u5B89\u88C5Vue-touter</p>
            <p>2\u3001\u9996\u5148\u65B0\u5EFA\u4E00\u4E2Arouter\u6587\u4EF6\u5939\uFF0C\u7136\u540E\u518D\u6587\u4EF6\u5939\u91CC\u65B0\u5EFA\u4E00\u4E2Aindex.js\u6587\u4EF6</p>
            <p>3\u3001\u5728main.js\u6CE8\u518Cindex.js\u6587\u4EF6</p>
            `,end:'<a target="_blank" href="https://next.router.vuejs.org/zh/introduction.html">\u672C\u6587\u53C2\u8003Vue-router\u5B98\u65B9\u6587\u6863</a>'}],imgSrc:["https://yubanblog-1254028239.cos.ap-guangzhou.myqcloud.com/article/vite_logo.svg"],tagTextArr:["\u524D\u7AEF","vue","JS"],articleDate:"2021-11-23",checkNum:"114514",codeLine:[{html:"",css:"",js:[`
//JS
//\u5B89\u88C5vue-router
npm install vue-router@next
            `,`
//index.js\u6587\u4EF6
import {            
    createRouter
    createWebHistory
} from 'vue-router'     //\u5BFC\u5165vue-router

//new \u8F6C\u6362\u6210\u5DE5\u5382\u51FD\u6570
//
const Home = () => import('../views/home.vue')
const About = () => import('../views/aoubt.vue)
const router = createRouter({
    history:createWebHistory(),
    routes:[
        {
            path:'/',
            component:Home
        },
        {
            path:'/about',
            component:About
        }
    ]
})
// \u66B4\u9732router
export default router
`,`
//main.js\u6587\u4EF6
//\u5BFC\u5165index.js\u6587\u4EF6
import router from './router/index'
//\u5C06\u5BFC\u5165\u8FDB\u6765\u7684index.js\u6302\u8F7D\u5230vue\u4E0A
app.use(router)
`]}],subtitle:{html:"",css:"",js:"JS\u90E8\u5206",end:"END"}},8:{articleId:8,articleTitle:"\u524D\u7AEF\u4E00\u4E9B\u9762\u8BD5\u9898",describe:"\u9762\u8BD5\u516B\u80A1\u6587\uFF0C\u9762\u8BD5\u9020\u822A\u6BCD\uFF0C\u5DE5\u4F5C\u62E7\u87BA\u4E1D\uFF01\u795D\u5927\u5BB6\u90FD\u80FD\u8FDB\u5927\u5382\uFF01",subtitle:{html:"",css:"CSS\u90E8\u5206",js:"JS\u90E8\u5206",end:"END"},articleText:[{html:`
            `,css:`
            <h3>CSS \u4E2D link \u548C@import \u7684\u533A\u522B\u662F\uFF1A</h3>
            <p>Link \u5C5E\u4E8E html \u6807\u7B7E\uFF0C\u800C@import \u662F CSS \u4E2D\u63D0\u4F9B\u7684
            \u5728\u9875\u9762\u52A0\u8F7D\u7684\u65F6\u5019\uFF0Clink \u4F1A\u540C\u65F6\u88AB\u52A0\u8F7D\uFF0C\u800C@import \u5F15\u7528\u7684 CSS \u4F1A\u5728\u9875\u9762\u52A0\u8F7D\u5B8C\u6210\u540E\u624D\u4F1A\u52A0
            \u8F7D\u5F15\u7528\u7684 CSS</p>
            <p>@import \u53EA\u6709\u5728 ie5 \u4EE5\u4E0A\u624D\u53EF\u4EE5\u88AB\u8BC6\u522B\uFF0C\u800C link \u662F html \u6807\u7B7E\uFF0C\u4E0D\u5B58\u5728\u6D4F\u89C8\u5668\u517C\u5BB9\u6027\u95EE\u9898
            Link \u5F15\u5165\u6837\u5F0F\u7684\u6743\u91CD\u5927\u4E8E@import \u7684\u5F15\u7528\uFF08@import \u662F\u5C06\u5F15\u7528\u7684\u6837\u5F0F\u5BFC\u5165\u5230\u5F53\u524D\u7684\u9875\u9762\u4E2D\uFF09
            </p>
            <br/>
            <h3>BFC \u662F\u4EC0\u4E48? </h3>
            <p>BFC\uFF08\u5757\u7EA7\u683C\u5F0F\u5316\u4E0A\u4E0B\u6587\uFF09\uFF0C\u4E00\u4E2A\u521B\u5EFA\u4E86\u65B0\u7684 BFC \u7684\u76D2\u5B50\u662F\u72EC\u7ACB\u5E03\u5C40\u7684\uFF0C\u76D2\u5B50\u5185\u5143\u7D20\u7684\u5E03\u5C40\u4E0D
            \u4F1A\u5F71\u54CD\u76D2\u5B50\u5916\u9762\u7684\u5143\u7D20\u3002\u5728\u540C\u4E00\u4E2A BFC \u4E2D\u7684\u4E24\u4E2A\u76F8\u90BB\u7684\u76D2\u5B50\u5728\u5782\u76F4\u65B9\u5411\u53D1\u751F margin \u91CD\u53E0\u7684
            \u95EE\u9898</p>
            <p>BFC \u662F\u6307\u6D4F\u89C8\u5668\u4E2D\u521B\u5EFA\u4E86\u4E00\u4E2A\u72EC\u7ACB\u7684\u6E32\u67D3\u533A\u57DF\uFF0C\u8BE5\u533A\u57DF\u5185\u6240\u6709\u5143\u7D20\u7684\u5E03\u5C40\u4E0D\u4F1A\u5F71\u54CD\u5230\u533A\u57DF\u5916
            \u5143\u7D20\u7684\u5E03\u5C40\uFF0C\u8FD9\u4E2A\u6E32\u67D3\u533A\u57DF\u53EA\u5BF9\u5757\u7EA7\u5143\u7D20\u8D77\u4F5C\u7528
            </p>
            <br/>
            <h3>CSS \u4E2D\u53EF\u4EE5\u901A\u8FC7\u54EA\u4E9B\u5C5E\u6027\u5B9A\u4E49\uFF0C\u4F7F\u5F97\u4E00\u4E2A DOM \u5143\u7D20\u4E0D\u663E\u793A\u5728\u6D4F\u89C8\u5668\u53EF\u89C6\u8303\u56F4\u5185\uFF1F\uFF1F</h3>
            <p>CSS \u4E2D\u53EF\u4EE5\u901A\u8FC7\u54EA\u4E9B\u5C5E\u6027\u5B9A\u4E49\uFF0C\u4F7F\u5F97\u4E00\u4E2A DOM \u5143\u7D20\u4E0D\u663E\u793A\u5728\u6D4F\u89C8\u5668\u53EF\u89C6\u8303\u56F4\u5185\uFF1F </p>
            <br/>
            <h3>\u8D85\u94FE\u63A5\u8BBF\u95EE\u8FC7\u540E hover \u6837\u5F0F\u5C31\u4E0D\u51FA\u73B0\u7684\u95EE\u9898\u662F\u4EC0\u4E48\uFF1F\u5982\u4F55\u89E3\u51B3\uFF1F</h3>
            <p>\u88AB\u70B9\u51FB\u8BBF\u95EE\u8FC7\u7684\u8D85\u94FE\u63A5\u6837\u5F0F\u4E0D\u5728\u5177\u6709 hover \u548C active \u4E86,\u89E3\u51B3\u65B9\u6CD5\u662F\u6539\u53D8 CSS
            \u5C5E\u6027\u7684\u6392\u5217\u987A\u5E8F: L-V-H-A\uFF08link,visited,hover,active\uFF09</p>
            <br/>
            <h3>display \u5C5E\u6027\u6709\u54EA\u4E9B\uFF1F\u53EF\u4EE5\u505A\u4EC0\u4E48\uFF1F</h3>
            <p>display:block \u884C\u5185\u5143\u7D20\u8F6C\u6362\u4E3A\u5757\u7EA7\u5143\u7D20</p>
            <p>display:block \u884C\u5185\u5143\u7D20\u8F6C\u6362\u4E3A\u5757\u7EA7\u5143\u7D20</p>
            <p>display:inline-block \u8F6C\u4E3A\u5185\u8054\u5143\u7D20</p>
            <br/>
            <h3>\u54EA\u4E9B css \u5C5E\u6027\u53EF\u4EE5\u7EE7\u627F\uFF1F</h3>
            <p>\u53EF\u7EE7\u627F\uFF1A font-size font-family color, ul li dl dd dt;</p>
            <p>\u4E0D\u53EF\u7EE7\u627F \uFF1Aborder padding margin width height ;</p>
            <br/>
            <h3>css \u4F18\u5148\u7EA7\u7B97\u6CD5\u5982\u4F55\u8BA1\u7B97\uFF1F</h3>
            <p>!important > id > class > \u6807\u7B7E</p>
            <p>!important \u6BD4 \u5185\u8054\u4F18\u5148\u7EA7\u9AD8</p>
            <p>*\u4F18\u5148\u7EA7\u5C31\u8FD1\u539F\u5219\uFF0C\u6837\u5F0F\u5B9A\u4E49\u6700\u8FD1\u8005\u4E3A\u51C6;</p>
            <p>*\u4EE5\u6700\u540E\u8F7D\u5165\u7684\u6837\u5F0F\u4E3A\u51C6;</p>
            <br/>`,js:`
            <h3></h3>
            <p></p>
            <br/>
            `,end:"\u5173\u4E8E\u524D\u7AEF\u7684\u4E00\u4E9B\u9762\u8BD5\u9898\u5C31\u5199\u5230\u7740\uFF0C\u540E\u671F\u6709\u7A7A\u518D\u8865\u5145\u55F7"}],codeLine:[{html:"",css:"",js:`
//JS\u90E8\u5206\u4EE3\u7801\u793A\u4F8B
//1\u3001javascript \u7684 typeof \u8FD4\u56DE\u54EA\u4E9B\u6570\u636E\u7C7B\u578B 

object number function boolean underfind string
typeof null;//object
typeof isNaN;//
typeof isNaN(123)
typeof [];//object
Array.isARRAY(); es5
toString.call([]);//\u201D[object Array]\u201D
var arr=[];
arr.constructor;//Array


//2\u3001\u4F8B\u4E3E 3 \u79CD\u5F3A\u5236\u7C7B\u578B\u8F6C\u6362\u548C 2 \u79CD\u9690\u5F0F\u7C7B\u578B\u8F6C\u6362? 

\u5F3A\u5236(\uFF08)parseInt,parseFloat,Number()\uFF09
\u9690\u5F0F\uFF08==\uFF09
1==\u201D1\u201D//true
null==undefined//true


//3\u3001\u6570\u7EC4\u65B9\u6CD5

pop() push() unshift() shift() 
Push()\u5C3E\u90E8\u6DFB\u52A0 pop()\u5C3E\u90E8\u5220\u9664
Unshift()\u5934\u90E8\u6DFB\u52A0 shift()\u5934\u90E8\u5220\u9664


//4\u3001IE \u548C\u6807\u51C6\u4E0B\u6709\u54EA\u4E9B\u517C\u5BB9\u6027\u7684\u5199\u6CD5

var ev = ev || window.event
document.documentElement.clientWidth || document.body.clientWidth
var target = ev.srcElement||ev.target


//5\u3001call \u548C apply \u7684\u533A\u522B

//call \u548C apply \u76F8\u540C\u70B9\uFF1A
//\u90FD\u662F\u4E3A\u4E86\u7528\u4E00\u4E2A\u672C\u4E0D\u5C5E\u4E8E\u4E00\u4E2A\u5BF9\u8C61\u7684\u65B9\u6CD5\uFF0C\u8BA9\u8FD9\u4E2A\u5BF9\u8C61\u53BB\u6267\u884C
toString.call([],1,2,3)
toString.apply([],[1,2,3])
Object.call(this,obj1,obj2,obj3)
Object.apply(this,arguments)


//6\u3001\u6DFB\u52A0 \u5220\u9664 \u66FF\u6362 \u63D2\u5165\u5230\u67D0\u4E2A\u63A5\u70B9\u7684\u65B9\u6CD5

obj.appendChild()
obj.insertBefore() //\u539F\u751F\u7684 js \u4E2D\u4E0D\u63D0\u4F9B insertAfter();
obj.replaceChild()//\u66FF\u6362
obj.removeChild()//\u5220\u9664


//7\u3001\u7F16\u5199\u4E00\u4E2A\u6570\u7EC4\u53BB\u91CD\u7684\u65B9\u6CD5

var arr=[1,1,3,4,2,4,7];
//=>[1,3,4,2,7]
//\u4E00\u4E2A\u6BD4\u8F83\u7B80\u5355\u7684\u5B9E\u73B0\u5C31\u662F\uFF1A
//1\u3001 \u5148\u521B\u5EFA\u4E00\u4E2A\u7A7A\u6570\u7EC4\uFF0C\u7528\u6765\u4FDD\u5B58\u6700\u7EC8\u7684\u7ED3\u679C
//2\u3001 \u5FAA\u73AF\u539F\u6570\u7EC4\u4E2D\u7684\u6BCF\u4E2A\u5143\u7D20
//3\u3001 \u518D\u5BF9\u6BCF\u4E2A\u5143\u7D20\u8FDB\u884C\u4E8C\u6B21\u5FAA\u73AF\uFF0C\u5224\u65AD\u662F\u5426\u6709\u4E0E\u4E4B\u76F8\u540C\u7684\u5143\u7D20\uFF0C\u5982\u679C\u6CA1\u6709\uFF0C\u5C06\u628A\u8FD9\u4E2A\u5143\u7D20\u653E
//\u5230\u65B0\u6570\u7EC4\u4E2D
//4\u3001 \u8FD4\u56DE\u8FD9\u4E2A\u65B0\u6570\u7EC4
function oSort(arr) {
var result ={};
var newArr=[];
for(var i=0;i < arr.length;i++){
if(!result[arr]) {
newArr.push(arr)
result[arr]=1
}
}
return newArr
}


//8\u3001\u8F93\u51FA\u4ECA\u5929\u7684\u65E5\u671F\uFF0C\u4EE5 YYYY-MM-DD \u7684\u65B9\u5F0F\uFF0C\u6BD4\u5982\u4ECA\u5929\u662F 2014 \u5E74 9 \u6708 26 \u65E5\uFF0C\u5219\u8F93\u51FA 2014-09-26

var d = new Date();
// \u83B7\u53D6\u5E74\uFF0CgetFullYear()\u8FD4\u56DE 4 \u4F4D\u7684\u6570\u5B57
var year = d.getFullYear();
// \u83B7\u53D6\u6708\uFF0C\u6708\u4EFD\u6BD4\u8F83\u7279\u6B8A\uFF0C0 \u662F 1 \u6708\uFF0C11 \u662F 12 \u6708
var month = d.getMonth() + 1;
// \u53D8\u6210\u4E24\u4F4D
month = month < 10 ? '0' + month : month;
// \u83B7\u53D6\u65E5
var day = d.getDate();
day = day < 10 ? '0' + day : day;
alert(year + '-' + month + '-' + day);


//9\u3001\u5224\u65AD\u4E00\u4E2A\u5B57\u7B26\u4E32\u4E2D\u51FA\u73B0\u6B21\u6570\u6700\u591A\u7684\u5B57\u7B26\uFF0C\u7EDF\u8BA1\u8FD9\u4E2A\u6B21\u6570

var str = 'asdfssaaasasasasaa';
var json = {};
for (var i = 0; i < str.length; i++) {
    if(!json[str.charAt(i)]){
    json[str.charAt(i)] = 1;
    }else{
        json[str.charAt(i)]++;
    }
};
var iMax = 0;
var iIndex = '';
    for(var i in json){
        if(json[i] > iMax){
        iMax = json[i];
        iIndex = i;
    }
}
alert('\u51FA\u73B0\u6B21\u6570\u6700\u591A\u7684\u662F:'+iIndex+'\u51FA\u73B0'+iMax+'\u6B21');

`}],imgSrc:["https://yubanblog-1254028239.cos.ap-guangzhou.myqcloud.com/article/WEB.jpg"],tagTextArr:["\u524D\u7AEF","\u9762\u8BD5","JS"],articleDate:"2021-11-23",checkNum:"114514"},9:{articleId:9,articleTitle:"vue\u603B\u7ED3---\u9762\u8BD5\u5F00\u53D1\u5168\u9760\u5B83\u4E86",describe:"vue\u603B\u7ED3---\u9762\u8BD5\u5F00\u53D1\u5168\u9760\u5B83\u4E86",articleText:[{html:"",css:"",js:`
            <h3>\u8BF7\u8BE6\u7EC6\u8BF4\u4E0B\u4F60\u5BF9vue\u751F\u547D\u5468\u671F\u7684\u7406\u89E3\uFF1F</h3>
            <p>\u603B\u5171\u5206\u4E3A8\u4E2A\u9636\u6BB5\u521B\u5EFA\u524D/\u540E\uFF0C\u8F7D\u5165\u524D/\u540E\uFF0C\u66F4\u65B0\u524D/\u540E\uFF0C\u9500\u6BC1\u524D/\u540E\u3002</p>
            <p>\u521B\u5EFA\u524D/\u540E\uFF1A \u5728beforeCreate\u9636\u6BB5\uFF0Cvue\u5B9E\u4F8B\u7684\u6302\u8F7D\u5143\u7D20el\u548C\u6570\u636E\u5BF9\u8C61data\u90FD\u4E3Aundefined\uFF0C\u8FD8\u672A\u521D\u59CB\u5316\u3002\u5728created\u9636\u6BB5\uFF0Cvue\u5B9E\u4F8B\u7684\u6570\u636E\u5BF9\u8C61data\u6709\u4E86\uFF0Cel\u4E3Aundefined\uFF0C\u8FD8\u672A\u521D\u59CB\u5316\u3002</p>
            <p>\u8F7D\u5165\u524D/\u540E\uFF1A\u5728beforeMount\u9636\u6BB5\uFF0Cvue\u5B9E\u4F8B\u7684$el\u548Cdata\u90FD\u521D\u59CB\u5316\u4E86\uFF0C\u4F46\u8FD8\u662F\u6302\u8F7D\u4E4B\u524D\u4E3A\u865A\u62DF\u7684dom\u8282\u70B9\uFF0Cdata.message\u8FD8\u672A\u66FF\u6362\u3002\u5728mounted\u9636\u6BB5\uFF0Cvue\u5B9E\u4F8B\u6302\u8F7D\u5B8C\u6210\uFF0Cdata.message\u6210\u529F\u6E32\u67D3\u3002</p>
            <p>\u66F4\u65B0\u524D/\u540E\uFF1A\u5F53data\u53D8\u5316\u65F6\uFF0C\u4F1A\u89E6\u53D1beforeUpdate\u548Cupdated\u65B9\u6CD5</p>
            <p>\u9500\u6BC1\u524D/\u540E\uFF1A\u5728\u6267\u884Cdestroy\u65B9\u6CD5\u540E\uFF0C\u5BF9data\u7684\u6539\u53D8\u4E0D\u4F1A\u518D\u89E6\u53D1\u5468\u671F\u51FD\u6570\uFF0C\u8BF4\u660E\u6B64\u65F6vue\u5B9E\u4F8B\u5DF2\u7ECF\u89E3\u9664\u4E86\u4E8B\u4EF6\u76D1\u542C\u4EE5\u53CA\u548Cdom\u7684\u7ED1\u5B9A\uFF0C\u4F46\u662Fdom\u7ED3\u6784\u4F9D\u7136\u5B58\u5728</p>
            <br/>
            <h3>\u4E3A\u4EC0\u4E48vue\u7EC4\u4EF6\u4E2Ddata\u5FC5\u987B\u662F\u4E00\u4E2A\u51FD\u6570\uFF1F</h3>
            <p>\u5BF9\u8C61\u4E3A\u5F15\u7528\u7C7B\u578B\uFF0C\u5F53\u590D\u7528\u7EC4\u4EF6\u65F6\uFF0C\u7531\u4E8E\u6570\u636E\u5BF9\u8C61\u90FD\u6307\u5411\u540C\u4E00\u4E2Adata\u5BF9\u8C61\uFF0C\u5F53\u5728\u4E00\u4E2A\u7EC4\u4EF6\u4E2D\u4FEE\u6539data\u65F6\uFF0C\u5176\u4ED6\u91CD\u7528\u7684\u7EC4\u4EF6\u4E2D\u7684data\u4F1A\u540C\u65F6\u88AB\u4FEE\u6539\uFF1B\u800C\u4F7F\u7528\u8FD4\u56DE\u5BF9\u8C61\u7684\u51FD\u6570\uFF0C\u7531\u4E8E\u6BCF\u6B21\u8FD4\u56DE\u7684\u90FD\u662F\u4E00\u4E2A\u65B0\u5BF9\u8C61\uFF08Object\u7684\u5B9E\u4F8B\uFF09\uFF0C\u5F15\u7528\u5730\u5740\u4E0D\u540C\uFF0C\u5219\u4E0D\u4F1A\u51FA\u73B0\u8FD9\u4E2A\u95EE\u9898\u3002</p>
            <br/>
            <h3>vue\u4E2Dv-if\u548Cv-show\u6709\u4EC0\u4E48\u533A\u522B\uFF1F</h3>
            <p>v-if\u548Cv-show\u770B\u8D77\u6765\u4F3C\u4E4E\u5DEE\u4E0D\u591A\uFF0C\u5F53\u6761\u4EF6\u4E0D\u6210\u7ACB\u65F6\uFF0C\u5176\u6240\u5BF9\u5E94\u7684\u6807\u7B7E\u5143\u7D20\u90FD\u4E0D\u53EF\u89C1\uFF0C\u4F46\u662F\u8FD9\u4E24\u4E2A\u9009\u9879\u662F\u6709\u533A\u522B\u7684:</p>
            <p>1\u3001v-if\u5728\u6761\u4EF6\u5207\u6362\u65F6\uFF0C\u4F1A\u5BF9\u6807\u7B7E\u8FDB\u884C\u9002\u5F53\u7684\u521B\u5EFA\u548C\u9500\u6BC1\uFF0C\u800Cv-show\u5219\u4EC5\u5728\u521D\u59CB\u5316\u65F6\u52A0\u8F7D\u4E00\u6B21\uFF0C\u56E0\u6B64v-if\u7684\u5F00\u9500\u76F8\u5BF9\u6765\u8BF4\u4F1A\u6BD4v-show\u5927\u3002</p>
            <p>2\u3001v-if\u662F\u60F0\u6027\u7684\uFF0C\u53EA\u6709\u5F53\u6761\u4EF6\u4E3A\u771F\u65F6\u624D\u4F1A\u771F\u6B63\u6E32\u67D3\u6807\u7B7E\uFF1B\u5982\u679C\u521D\u59CB\u6761\u4EF6\u4E0D\u4E3A\u771F\uFF0C\u5219v-if\u4E0D\u4F1A\u53BB\u6E32\u67D3\u6807\u7B7E\u3002v-show\u5219\u65E0\u8BBA\u521D\u59CB\u6761\u4EF6\u662F\u5426\u6210\u7ACB\uFF0C\u90FD\u4F1A\u6E32\u67D3\u6807\u7B7E\uFF0C\u5B83\u4EC5\u4EC5\u505A\u7684\u53EA\u662F\u7B80\u5355\u7684CSS\u5207\u6362\u3002</p>
            <br/>
            <h3>computed\u548Cwatch\u7684\u533A\u522B</h3>
            <p>\u8BA1\u7B97\u5C5E\u6027computed\uFF1A</p>
            <p>\u652F\u6301\u7F13\u5B58\uFF0C\u53EA\u6709\u4F9D\u8D56\u6570\u636E\u53D1\u751F\u6539\u53D8\uFF0C\u624D\u4F1A\u91CD\u65B0\u8FDB\u884C\u8BA1\u7B97</p>
            <p>\u4E0D\u652F\u6301\u5F02\u6B65\uFF0C\u5F53computed\u5185\u6709\u5F02\u6B65\u64CD\u4F5C\u65F6\u65E0\u6548\uFF0C\u65E0\u6CD5\u76D1\u542C\u6570\u636E\u7684\u53D8\u5316</p>
            <p>computed \u5C5E\u6027\u503C\u4F1A\u9ED8\u8BA4\u8D70\u7F13\u5B58\uFF0C\u8BA1\u7B97\u5C5E\u6027\u662F\u57FA\u4E8E\u5B83\u4EEC\u7684\u54CD\u5E94\u5F0F\u4F9D\u8D56\u8FDB\u884C\u7F13\u5B58\u7684\uFF0C\u4E5F\u5C31\u662F\u57FA\u4E8Edata\u4E2D\u58F0\u660E\u8FC7\u6216\u8005\u7236\u7EC4\u4EF6\u4F20\u9012\u7684props\u4E2D\u7684\u6570\u636E\u901A\u8FC7\u8BA1\u7B97\u5F97\u5230\u7684\u503C</p>
            <p>\u5982\u679C\u4E00\u4E2A\u5C5E\u6027\u662F\u7531\u5176\u4ED6\u5C5E\u6027\u8BA1\u7B97\u800C\u6765\u7684\uFF0C\u8FD9\u4E2A\u5C5E\u6027\u4F9D\u8D56\u5176\u4ED6\u5C5E\u6027\uFF0C\u662F\u4E00\u4E2A\u591A\u5BF9\u4E00\u6216\u8005\u4E00\u5BF9\u4E00\uFF0C\u4E00\u822C\u7528computed</p>
            <p>\u5982\u679Ccomputed\u5C5E\u6027\u5C5E\u6027\u503C\u662F\u51FD\u6570\uFF0C\u90A3\u4E48\u9ED8\u8BA4\u4F1A\u8D70get\u65B9\u6CD5\uFF1B\u51FD\u6570\u7684\u8FD4\u56DE\u503C\u5C31\u662F\u5C5E\u6027\u7684\u5C5E\u6027\u503C\uFF1B\u5728computed\u4E2D\u7684\uFF0C\u5C5E\u6027\u90FD\u6709\u4E00\u4E2Aget\u548C\u4E00\u4E2Aset\u65B9\u6CD5\uFF0C\u5F53\u6570\u636E\u53D8\u5316\u65F6\uFF0C\u8C03\u7528set\u65B9\u6CD5\u3002</p>
            <p>\u4FA6\u542C\u5C5E\u6027watch\uFF1A</p>
            <p>\u4E0D\u652F\u6301\u7F13\u5B58\uFF0C\u6570\u636E\u53D8\uFF0C\u76F4\u63A5\u4F1A\u89E6\u53D1\u76F8\u5E94\u7684\u64CD\u4F5C\uFF1B</p>
            <p>watch\u652F\u6301\u5F02\u6B65\uFF1B</p>
            <p>\u76D1\u542C\u7684\u51FD\u6570\u63A5\u6536\u4E24\u4E2A\u53C2\u6570\uFF0C\u7B2C\u4E00\u4E2A\u53C2\u6570\u662F\u6700\u65B0\u7684\u503C\uFF1B\u7B2C\u4E8C\u4E2A\u53C2\u6570\u662F\u8F93\u5165\u4E4B\u524D\u7684\u503C\uFF1B</p>
            <p>\u5F53\u4E00\u4E2A\u5C5E\u6027\u53D1\u751F\u53D8\u5316\u65F6\uFF0C\u9700\u8981\u6267\u884C\u5BF9\u5E94\u7684\u64CD\u4F5C\uFF1B\u4E00\u5BF9\u591A\uFF1B</p>
            <p>\u76D1\u542C\u6570\u636E\u5FC5\u987B\u662Fdata\u4E2D\u58F0\u660E\u8FC7\u6216\u8005\u7236\u7EC4\u4EF6\u4F20\u9012\u8FC7\u6765\u7684props\u4E2D\u7684\u6570\u636E\uFF0C\u5F53\u6570\u636E\u53D8\u5316\u65F6\uFF0C\u89E6\u53D1\u5176\u4ED6\u64CD\u4F5C\uFF0C\u51FD\u6570\u6709\u4E24\u4E2A\u53C2\u6570\uFF1A</p>
            <p>immediate\uFF1A\u7EC4\u4EF6\u52A0\u8F7D\u7ACB\u5373\u89E6\u53D1\u56DE\u8C03\u51FD\u6570\u6267\u884C</p>
            <br/>
            <h3>$nextTick\u662F\u4EC0\u4E48\uFF1F</h3>
            <p>vue\u5B9E\u73B0\u54CD\u5E94\u5F0F\u5E76\u4E0D\u662F\u6570\u636E\u53D1\u751F\u53D8\u5316\u540Edom\u7ACB\u5373\u53D8\u5316\uFF0C\u800C\u662F\u6309\u7167\u4E00\u5B9A\u7684\u7B56\u7565\u6765\u8FDB\u884Cdom\u66F4\u65B0\u3002</p>
            <p>nextTick \u662F\u5728\u4E0B\u6B21 DOM \u66F4\u65B0\u5FAA\u73AF\u7ED3\u675F\u4E4B\u540E\u6267\u884C\u5EF6\u8FDF\u56DE\u8C03\uFF0C\u5728\u4FEE\u6539\u6570\u636E\u4E4B\u540E\u4F7F\u7528</p>
            <p>nextTick\uFF0C\u5219\u53EF\u4EE5\u5728\u56DE\u8C03\u4E2D\u83B7\u53D6\u66F4\u65B0\u540E\u7684 DOM</p>
            <br/>
            <h3>v-for key\u7684\u4F5C\u7528</h3>
            <p>\u5F53Vue\u7528 v-for \u6B63\u5728\u66F4\u65B0\u5DF2\u6E32\u67D3\u8FC7\u7684\u5143\u7D20\u5217\u8868\u662F\uFF0C\u5B83\u9ED8\u8BA4\u7528\u201C\u5C31\u5730\u590D\u7528\u201D\u7B56\u7565\u3002\u5982\u679C\u6570\u636E\u9879\u7684\u987A\u5E8F\u88AB\u6539\u53D8\uFF0CVue\u5C06\u4E0D\u662F\u79FB\u52A8DOM\u5143\u7D20\u6765\u5339\u914D\u6570\u636E\u9879\u7684\u6539\u53D8\uFF0C\u800C\u662F\u7B80\u5355\u590D\u7528\u6B64\u5904\u6BCF\u4E2A\u5143\u7D20\uFF0C\u5E76\u4E14\u786E\u4FDD\u5B83\u5728\u7279\u5B9A\u7D22\u5F15\u4E0B\u663E\u793A\u5DF2\u88AB\u6E32\u67D3\u8FC7\u7684\u6BCF\u4E2A\u5143\u7D20\u3002</p>
            <p>\u4E3A\u4E86\u7ED9Vue\u4E00\u4E2A\u63D0\u793A\uFF0C\u4EE5\u4FBF\u5B83\u80FD\u8DDF\u8E2A\u6BCF\u4E2A\u8282\u70B9\u7684\u8EAB\u4EFD\uFF0C\u4ECE\u800C\u91CD\u7528\u548C\u91CD\u65B0\u6392\u5E8F\u73B0\u6709\u5143\u7D20\uFF0C\u4F60\u9700\u8981\u4E3A\u6BCF\u9879\u63D0\u4F9B\u4E00\u4E2A\u552F\u4E00 key \u5C5E\u6027\u3002key\u5C5E\u6027\u7684\u7C7B\u578B\u53EA\u80FD\u4E3A string\u6216\u8005number\u7C7B\u578B\u3002</p>
            <p>key \u7684\u7279\u6B8A\u5C5E\u6027\u4E3B\u8981\u7528\u5728Vue\u7684\u865A\u62DFDOM\u7B97\u6CD5\uFF0C\u5728\u65B0\u65E7nodes\u5BF9\u6BD4\u65F6\u8FA8\u8BC6VNodes\u3002\u5982\u679C\u4E0D\u4F7F\u7528 key\uFF0CVue\u4F1A\u4F7F\u7528\u4E00\u79CD\u6700\u5927\u9650\u5EA6\u51CF\u5C11\u52A8\u6001\u5143\u7D20\u5E76\u4E14\u5C3D\u53EF\u80FD\u7684\u5C1D\u8BD5\u4FEE\u590D/\u518D\u5229\u7528\u76F8\u540C\u7C7B\u578B\u5143\u7D20\u7684\u7B97\u6CD5\u3002\u4F7F\u7528key\uFF0C\u5B83\u4F1A\u57FA\u4E8Ekey\u7684\u53D8\u5316\u91CD\u65B0\u6392\u5217\u5143\u7D20\u987A\u5E8F\uFF0C\u5E76\u4E14\u4F1A\u79FB\u9664 key \u4E0D\u5B58\u5728\u7684\u5143\u7D20\u3002</p>
            <br/>
            <h3>Vue\u7684\u53CC\u5411\u6570\u636E\u7ED1\u5B9A\u539F\u7406\u662F\u4EC0\u4E48\uFF1F</h3>
            <p>vue.js \u662F\u91C7\u7528\u6570\u636E\u52AB\u6301\u7ED3\u5408\u53D1\u5E03\u8005-\u8BA2\u9605\u8005\u6A21\u5F0F\u7684\u65B9\u5F0F\uFF0C\u901A\u8FC7Object.defineProperty()\u6765\u52AB\u6301\u5404\u4E2A\u5C5E\u6027\u7684setter\uFF0Cgetter\uFF0C\u5728\u6570\u636E\u53D8\u52A8\u65F6\u53D1\u5E03\u6D88\u606F\u7ED9\u8BA2\u9605\u8005\uFF0C\u89E6\u53D1\u76F8\u5E94\u7684\u76D1\u542C\u56DE\u8C03\u3002\u4E3B\u8981\u5206\u4E3A\u4EE5\u4E0B\u51E0\u4E2A\u6B65\u9AA4\uFF1A</p>
            <p> 1\u3001\u9700\u8981observe\u7684\u6570\u636E\u5BF9\u8C61\u8FDB\u884C\u9012\u5F52\u904D\u5386\uFF0C\u5305\u62EC\u5B50\u5C5E\u6027\u5BF9\u8C61\u7684\u5C5E\u6027\uFF0C\u90FD\u52A0\u4E0Asetter\u548Cgetter\u8FD9\u6837\u7684\u8BDD\uFF0C\u7ED9\u8FD9\u4E2A\u5BF9\u8C61\u7684\u67D0\u4E2A\u503C\u8D4B\u503C\uFF0C\u5C31\u4F1A\u89E6\u53D1setter\uFF0C\u90A3\u4E48\u5C31\u80FD\u76D1\u542C\u5230\u4E86\u6570\u636E\u53D8\u5316</p>
            <p> 2\u3001compile\u89E3\u6790\u6A21\u677F\u6307\u4EE4\uFF0C\u5C06\u6A21\u677F\u4E2D\u7684\u53D8\u91CF\u66FF\u6362\u6210\u6570\u636E\uFF0C\u7136\u540E\u521D\u59CB\u5316\u6E32\u67D3\u9875\u9762\u89C6\u56FE\uFF0C\u5E76\u5C06\u6BCF\u4E2A\u6307\u4EE4\u5BF9\u5E94\u7684\u8282\u70B9\u7ED1\u5B9A\u66F4\u65B0\u51FD\u6570\uFF0C\u6DFB\u52A0\u76D1\u542C\u6570\u636E\u7684\u8BA2\u9605\u8005\uFF0C\u4E00\u65E6\u6570\u636E\u6709\u53D8\u52A8\uFF0C\u6536\u5230\u901A\u77E5\uFF0C\u66F4\u65B0\u89C6\u56FE</p>
            <p> 3\u3001Watcher\u8BA2\u9605\u8005\u662FObserver\u548CCompile\u4E4B\u95F4\u901A\u4FE1\u7684\u6865\u6881\uFF0C\u4E3B\u8981\u505A\u7684\u4E8B\u60C5\u662F:
            \u2460\u5728\u81EA\u8EAB\u5B9E\u4F8B\u5316\u65F6\u5F80\u5C5E\u6027\u8BA2\u9605\u5668(dep)\u91CC\u9762\u6DFB\u52A0\u81EA\u5DF1
            \u2461\u81EA\u8EAB\u5FC5\u987B\u6709\u4E00\u4E2Aupdate()\u65B9\u6CD5
            \u2462\u5F85\u5C5E\u6027\u53D8\u52A8dep.notice()\u901A\u77E5\u65F6\uFF0C\u80FD\u8C03\u7528\u81EA\u8EAB\u7684update()\u65B9\u6CD5\uFF0C\u5E76\u89E6\u53D1Compile\u4E2D\u7ED1\u5B9A\u7684\u56DE\u8C03\uFF0C\u5219\u529F\u6210\u8EAB\u9000\u3002</p>
            <p> 4\u3001MVVM\u4F5C\u4E3A\u6570\u636E\u7ED1\u5B9A\u7684\u5165\u53E3\uFF0C\u6574\u5408Observer\u3001Compile\u548CWatcher\u4E09\u8005\uFF0C\u901A\u8FC7Observer\u6765\u76D1\u542C\u81EA\u5DF1\u7684model\u6570\u636E\u53D8\u5316\uFF0C\u901A\u8FC7Compile\u6765\u89E3\u6790\u7F16\u8BD1\u6A21\u677F\u6307\u4EE4\uFF0C\u6700\u7EC8\u5229\u7528Watcher\u642D\u8D77Observer\u548CCompile\u4E4B\u95F4\u7684\u901A\u4FE1\u6865\u6881\uFF0C\u8FBE\u5230\u6570\u636E\u53D8\u5316 -> \u89C6\u56FE\u66F4\u65B0\uFF1B\u89C6\u56FE\u4EA4\u4E92\u53D8\u5316(input) -> \u6570\u636Emodel\u53D8\u66F4\u7684\u53CC\u5411\u7ED1\u5B9A\u6548\u679C\u3002</p>
            <br/>
            <h3></h3>
            <p></p>
            <br/>
            <h3></h3>
            <p></p>
            <br/>
            <h3></h3>
            <p></p>
            <br/>
            <h3></h3>
            <p></p>
            <br/>
            `,end:`
            <a href="https://juejin.cn/post/6850037277675454478">\u672C\u6587\u6574\u7406\u81EA\u6398\u91D1 \u53F2\u4E0A\u6700\u5F3Avue\u603B\u7ED3---\u9762\u8BD5\u5F00\u53D1\u5168\u9760\u5B83\u4E86</a>
            `}],subtitle:{html:"",css:"",js:"JS\u90E8\u5206",end:"END"},imgSrc:["https://yubanblog-1254028239.cos.ap-guangzhou.myqcloud.com/article/vue_logo.svg"],tagTextArr:["\u524D\u7AEF","Vue","JS"],articleDate:"2021-11-23",checkNum:"114514",codeLine:[{html:"",css:"",js:`
//\u7EC4\u4EF6\u4F20\u503C
//\u7236\u4F20\u5B50
//\u901A\u8FC7props\u4F20\u9012

//\u7236\u7EC4\u4EF6\uFF1A 
< child value = '\u4F20\u9012\u7684\u6570\u636E' />

//\u5B50\u7EC4\u4EF6: 
props['value'] //\u63A5\u6536\u6570\u636E,\u63A5\u53D7\u4E4B\u540E\u4F7F\u7528\u548Cdata\u4E2D\u5B9A\u4E49\u6570\u636E\u4F7F\u7528\u65B9\u5F0F\u4E00\u6837
//\u5B50\u4F20\u7236 \u5728\u7236\u7EC4\u4EF6\u4E2D\u7ED9\u5B50\u7EC4\u4EF6\u7ED1\u5B9A\u4E00\u4E2A\u81EA\u5B9A\u4E49\u7684\u4E8B\u4EF6\uFF0C\u5B50\u7EC4\u4EF6\u901A\u8FC7$emit()\u89E6\u53D1\u8BE5\u4E8B\u4EF6\u5E76\u4F20\u503C\u3002

//\u7236\u7EC4\u4EF6\uFF1A 
<child @receive = 'receive' />

 //\u5B50\u7EC4\u4EF6: 
 this.$emit('receive','\u4F20\u9012\u7684\u6570\u636E')

 //\u5144\u5F1F\u7EC4\u4EF6\u4F20\u503C
    //\u901A\u8FC7\u4E2D\u592E\u901A\u4FE1 
 let bus = new Vue()
 //A\uFF1A
 methods :{ \u51FD\u6570{bus.$emit(\u2018\u81EA\u5B9A\u4E49\u4E8B\u4EF6\u540D\u2019\uFF0C\u6570\u636E)}  //\u53D1\u9001
 //B\uFF1A
 created(){bus.$on(\u2018A\u53D1\u9001\u8FC7\u6765\u7684\u81EA\u5B9A\u4E49\u4E8B\u4EF6\u540D\u2019\uFF0C\u51FD\u6570)} //\u8FDB\u884C\u6570\u636E\u63A5\u6536

`}]}};export{_ as T,A as _,J as a};
